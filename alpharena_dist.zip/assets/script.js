/* Бұл assets/script.js файлы */
